package com.cg.recruit.bean;

import java.sql.Date;

public class RecruitBean {

	private String user_id;
	private String password;
	private String desig;
	private int emp_id;
	private String emp_name;
	private int proj_id;
	private String skill;
	private int exp;
	private String dom;
	private String proj_name;
	private String desc;
	private Date s_date;
	private Date e_date;
	private int rm_id;
	
	public String getUser_id() {
		return user_id;
	}
	
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getDesig() {
		return desig;
	}
	
	public void setDesig(String desig) {
		this.desig = desig;
	}
	
	public int getEmp_id() {
		return emp_id;
	}
	
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	
	public String getEmp_name() {
		return emp_name;
	}
	
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	
	public int getProj_id() {
		return proj_id;
	}
	
	public void setProj_id(int proj_id) {
		this.proj_id = proj_id;
	}
	
	public String getSkill() {
		return skill;
	}
	
	public void setSkill(String skill) {
		this.skill = skill;
	}
	
	public int getExp() {
		return exp;
	}
	
	public void setExp(int exp) {
		this.exp = exp;
	}
	
	public String getDom() {
		return dom;
	}
	
	public void setDom(String dom) {
		this.dom = dom;
	}
	
	public String getProj_name() {
		return proj_name;
	}
	
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public Date getS_date() {
		return s_date;
	}
	
	public void setS_date(Date s_date) {
		this.s_date = s_date;
	}
	
	public Date getE_date() {
		return e_date;
	}
	
	public void setE_date(Date e_date) {
		this.e_date = e_date;
	}
	
	public int getRm_id() {
		return rm_id;
	}
	
	public void setRm_id(int rm_id) {
		this.rm_id = rm_id;
	}
	
}
