package com.cg.recruit.controller;
import javax.servlet.*;
import java.io.IOException;
import java.sql.*;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Recruit_login_Controller extends HttpServlet{


		
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
				    RequestDispatcher rd = null;
					String user_id=request.getParameter("username");
					String password=request.getParameter("password");
					String desig=request.getParameter("des");
					String p=request.getParameter("price");
					String sql;
					try {
					Conn c=new Conn();
					Connection c1=c.getCon();
					sql="SELECT user_id,password,role from user1 where user_id='"+user_id+"'AND password='"+password+"'";
					Statement pst=c1.createStatement();
					int i=0;
					i=pst.executeUpdate(sql);
					if (i==1) {
						rd = request.getRequestDispatcher("/success.jsp");
					} else {
						rd = request.getRequestDispatcher("/error.jsp");
					}
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
}
