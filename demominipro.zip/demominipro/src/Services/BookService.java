package Services;

import Beans.BookBean;
import Beans.RoomBean;
import Dao.BookDao;
import Dao.RoomDao;

public class BookService {

	public static int addBookService(String bookingid, String roomid, String userid, String fromdate, String todate,
			int children, int adults, int amount) {
		BookDao BookDAO = new BookDao();
		BookBean bookBean = new BookBean();
		
		bookBean.setBookingid(bookingid);
		bookBean.setRoomid(roomid);
		bookBean.setUserid(userid);
		bookBean.setFromdate(fromdate);
		bookBean.setTodate(todate);
		bookBean.setChildren(children);
		bookBean.setAdults(adults);
		bookBean.setAmount(amount);
		
		
		int updateResult = 0;
		 try
		 {
			 updateResult = BookDao.addBook(bookBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

}
