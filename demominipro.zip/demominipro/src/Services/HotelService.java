package Services;
import Beans.HotelBean;
import Beans.RegBean;
import Dao.HotelDao;
import Dao.RegDao;

public class HotelService {
	

	public static int addHtlService(String hotelid, String city, String hotelname, String address, String desc, int price,
			String phno1, String phno2, String rating, String email, String fax) {
		
		HotelDao htlDAO = new HotelDao();
		HotelBean htlBean = new HotelBean();
		htlBean.setHotelid(hotelid);
		htlBean.setCity(city);
		htlBean.setHotelname(hotelname);
		htlBean.setAddress(address);
		htlBean.setDesc(desc);
		htlBean.setPrice(price);
		htlBean.setPhno1(phno1);
		htlBean.setPhno2(phno2);
		htlBean.setRating(rating);
		htlBean.setEmail(email);
		htlBean.setFax(fax);
		
		int updateResult = 0;
		 try
		 {
			 updateResult = HotelDao.addHotel(htlBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

	public int delHotelService(int hotelid) {
		HotelDao htlDAO = new HotelDao();
		HotelBean htlBean = new HotelBean();
		int updateResult1 = 0;
		 try
		 {
			 updateResult1 = HotelDao.delHotel(hotelid);
			 return updateResult1;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

}