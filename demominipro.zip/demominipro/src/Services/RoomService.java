package Services;

import Beans.RegBean;
import Beans.RoomBean;
import Dao.RegDao;
import Dao.RoomDao;

public class RoomService {

	public static int addRoomService(String hotelid, String roomid, String roomno, String roomtype, int price,
			boolean aval) {
		
		RoomDao RmDAO = new RoomDao();
		RoomBean RmBean = new RoomBean();
		
		RmBean.setHotelid(hotelid);
		RmBean.setRoomid(roomid);
		RmBean.setRoomno(roomno);
		RmBean.setRoomtype(roomtype);
		RmBean.setPrice(price);
		RmBean.setAval(aval);
		
		int updateResult = 0;
		 try
		 {
			 updateResult = RoomDao.addRoom(RmBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

}
