package Services;

import Beans.RegBean;
import Dao.RegDao;

public class RegisterService {
	public static int addRegService(String userid, String pass, String name,double mobile,double phone,String address,String email) {
		
		RegDao bookDAO = new RegDao();
		RegBean RegBean = new RegBean();
		
		RegBean.setUserid(userid);
		RegBean.setPass(pass);
		RegBean.setName(name);
		RegBean.setMobile(mobile);
		RegBean.setPhone(phone);
		RegBean.setAddress(address);
		RegBean.setEmail(email);
		
		int updateResult = 0;
		 try
		 {
			 updateResult = RegDao.addReg(RegBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	 }
		
		
	}

