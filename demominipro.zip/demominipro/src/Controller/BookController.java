package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Services.BookService;
import Services.RegisterService;

public class BookController extends HttpServlet {
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
			{
		RequestDispatcher rd = null;
		String bookingid="";
		String roomid="";
		String userid="";
		String fromdate="";
		String todate="";
		int children=0;
		int adults=0;
		int amount=0;
		
		bookingid=request.getParameter("uid");
		
		roomid=request.getParameter("uid");
		
		userid=request.getParameter("uid");
		
		fromdate=request.getParameter("uid");
		
		todate=request.getParameter("uid");
		
		String c=request.getParameter("mno");
		children=Integer.parseInt(c);
		
		String a=request.getParameter("mno");
		adults=Integer.parseInt(a);
		
		String amt=request.getParameter("mno");
		amount=Integer.parseInt(amt);
		
		BookService bookService = new BookService();
		
		int updateCount = BookService.addBookService(bookingid, roomid, userid, fromdate, todate,children,adults,amount);
				
				System.out.println("inserted "+updateCount+" record   Success");
				
				if (updateCount==1) {
					rd = request.getRequestDispatcher("/success.jsp");
					
				} else {
					rd = request.getRequestDispatcher("/error.jsp");
				}
				rd.forward(request, response);
			}

}