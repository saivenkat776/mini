package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Services.HotelService;
import Services.RegisterService;

public class HotelController extends HttpServlet {
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
			{ 
		RequestDispatcher rd = null;
		String hotelid="";
		String city="";
		String hotelname="";
		String address="";
		String desc="";
		int price=0;
		String phno1="";
		String phno2="";
		String rating="";
		String email="";
		String fax="";
		

		hotelid=request.getParameter("hid");
		
		city=request.getParameter("cname");
		
		hotelname=request.getParameter("hname");
		
		address=request.getParameter("add");
		
		desc=request.getParameter("desc");
		
		String rate=request.getParameter("price");
		price=Integer.parseInt(rate);
		
		phno1=request.getParameter("phno1");
		
		phno2=request.getParameter("phno2");
		
		rating=request.getParameter("rating");
		
		email=request.getParameter("fname");
		
		fax=request.getParameter("fname");
		
int updateCount = HotelService.addHtlService(hotelid, city, hotelname, address, desc,price,phno1,phno2,rating,email,fax);
		
		System.out.println("inserted "+updateCount+" record   Success");
		
		if (updateCount==1) {
			rd = request.getRequestDispatcher("/success.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
		
			}
}
