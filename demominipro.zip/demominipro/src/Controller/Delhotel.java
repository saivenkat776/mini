package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Services.HotelService;

public class Delhotel extends HttpServlet {
	
	
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
			{
		RequestDispatcher rd = null;
		int hotelid=0;
		
		String id=request.getParameter("hid");
		hotelid=Integer.parseInt(id);
		
		HotelService HotelService1 = new HotelService();
		
		int updateCount1 = HotelService1.delHotelService(hotelid);
		
		System.out.println("deleted "+updateCount1+" record   Success");
		
		if (updateCount1==1) {
			rd = request.getRequestDispatcher("/table.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/errordelete.jsp");
		}
		rd.forward(request, response);
			}

}
