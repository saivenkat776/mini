package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Services.RegisterService;

public class RegisterController extends HttpServlet {
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
			{
		RequestDispatcher rd = null;
		String userid="";
		String pass="";
		String name="";
		double mobile=0;
		double phone=0;
		String address="";
		String email="";
		
		
		userid=request.getParameter("uid");
		
		pass=request.getParameter("pass");
		
		name=request.getParameter("fname");
		
		String mob=request.getParameter("mno");
		mobile=Double.parseDouble(mob);
		
		String phno=request.getParameter("phno");
		phone=Double.parseDouble(phno);
		
		address=request.getParameter("address");
		
		email=request.getParameter("email");
		
		RegisterService regService = new RegisterService();
		
int updateCount = RegisterService.addRegService(userid, pass, name, mobile, phone,address,email);
		
		System.out.println("inserted "+updateCount+" record   Success");
		
		if (updateCount==1) {
			rd = request.getRequestDispatcher("/success.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
			}
}
