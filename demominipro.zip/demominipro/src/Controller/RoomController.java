package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Services.RegisterService;
import Services.RoomService;

public class RoomController extends HttpServlet {
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException 
			{
		RequestDispatcher rd = null;
		String hotelid="";
		String roomid="";
		String roomno="";
		String roomtype="";
		int price=0;
		boolean aval="" != null;
		
		hotelid=request.getParameter("hname");
		
		roomid=request.getParameter("uid");
		
		roomno=request.getParameter("uid");
		
		roomtype=request.getParameter("uid");
		
		String rate=request.getParameter("mno");
		price=Integer.parseInt(rate);
		
		String avl=request.getParameter("mno");
		aval=Boolean.parseBoolean(avl);
		
		RoomService regService = new RoomService();
		
int updateCount = RoomService.addRoomService(hotelid, roomid, roomno, roomtype, price,aval);
		
		System.out.println("inserted "+updateCount+" record   Success");
		
		if (updateCount==1) {
			rd = request.getRequestDispatcher("/success.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
			}

}