package Beans;

import java.io.Serializable;

public class RoomBean implements Serializable{

	private String hotelid;
	private String roomid;
	private String roomno;
	private String roomtype;
	private int price;
	private boolean aval;
	public String getHotelid() {
		return hotelid;
	}
	public String getRoomid() {
		return roomid;
	}
	public String getRoomno() {
		return roomno;
	}
	public String getRoomtype() {
		return roomtype;
	}
	public int getPrice() {
		return price;
	}
	public boolean isAval() {
		return aval;
	}
	public void setHotelid(String hotelid) {
		this.hotelid = hotelid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public void setRoomno(String roomno) {
		this.roomno = roomno;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setAval(boolean aval) {
		this.aval = aval;
	}
	
	
}