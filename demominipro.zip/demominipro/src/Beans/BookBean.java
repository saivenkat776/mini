package Beans;

import java.io.Serializable;

public class BookBean implements Serializable{
	private String bookingid;
	private String roomid;
	private String userid;
	private String fromdate;
	private String todate;
	private int children;
	private int adults;
	private int amount;
	public String getBookingid() {
		return bookingid;
	}
	public String getRoomid() {
		return roomid;
	}
	public String getUserid() {
		return userid;
	}
	public String getFromdate() {
		return fromdate;
	}
	public String getTodate() {
		return todate;
	}
	public int getChildren() {
		return children;
	}
	public int getAdults() {
		return adults;
	}
	public int getAmount() {
		return amount;
	}
	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public void setChildren(int children) {
		this.children = children;
	}
	public void setAdults(int adults) {
		this.adults = adults;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
}