package Beans;

import java.io.Serializable;

public class HotelBean implements Serializable{
	
	private String hotelid;
	private String city;
	private String hotelname;
	private String address;
	private String desc;
	private int price;
	private String phno1;
	private String phno2;
	private String rating;
	private String email;
	private String fax;
	public String getHotelid() {
		return hotelid;
	}
	public String getCity() {
		return city;
	}
	public String getHotelname() {
		return hotelname;
	}
	public String getAddress() {
		return address;
	}
	public String getDesc() {
		return desc;
	}
	public int getPrice() {
		return price;
	}
	public String getPhno1() {
		return phno1;
	}
	public String getPhno2() {
		return phno2;
	}
	public String getRating() {
		return rating;
	}
	public String getEmail() {
		return email;
	}
	public String getFax() {
		return fax;
	}
	public void setHotelid(String hotelid) {
		this.hotelid = hotelid;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setPhno1(String phno1) {
		this.phno1 = phno1;
	}
	public void setPhno2(String phno2) {
		this.phno2 = phno2;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	
	
	
}
