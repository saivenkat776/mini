package Beans;

import java.io.Serializable;

public class RegBean implements Serializable
{
	  private String userid;
	  private String pass;
	  private String name;
	  private double mobile;
	  private double phone;
	  private String address;
	  private String email;
	public String getUserid() {
		return userid;
	}
	public String getPass() {
		return pass;
	}
	public String getName() {
		return name;
	}
	public double getMobile() {
		return mobile;
	}
	public double getPhone() {
		return phone;
	}
	public String getAddress() {
		return address;
	}
	public String getEmail() {
		return email;
	}
	public void setUserid(String userid2) {
		this.userid = userid2;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setMobile(double mobile) {
		this.mobile = mobile;
	}
	public void setPhone(double phone) {
		this.phone = phone;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	  
	  

}
