package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Beans.BookBean;

public class BookDao {

	public static int addBook(BookBean bookBean) {
		Connection con = null;
		  PreparedStatement pstmt = null;
		  try {
			  
con=DB.getConnection(); 
			  
			  String ins_str ="insert into demo values(?,?,?,?,?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,bookBean.getBookingid());
			  pstmt.setString(2,bookBean.getRoomid());
			  pstmt.setString(3,bookBean.getUserid());
			  pstmt.setString(4,bookBean.getFromdate());
			  pstmt.setString(5,bookBean.getTodate());
			  pstmt.setInt(6,bookBean.getChildren());
			  pstmt.setInt(7,bookBean.getAdults());
			  pstmt.setInt(8,bookBean.getAmount());
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
		  }catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	}

}