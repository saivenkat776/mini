package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Beans.HotelBean;

public class HotelDao {

	public static int addHotel(HotelBean htlBean) {
		Connection con = null;
		  PreparedStatement pstmt = null;
		  try {
			  
			  con=DB.getConnection(); 
			  
			  String ins_str ="insert into hdemo values(?,?,?,?,?,?,?,?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,htlBean.getHotelid());
			  pstmt.setString(2,htlBean.getCity());
			  pstmt.setString(3,htlBean.getHotelname());
			  pstmt.setString(4, htlBean.getAddress());
			  pstmt.setString(5, htlBean.getDesc());
			  pstmt.setInt(6,htlBean.getPrice());
			  pstmt.setString(7,htlBean.getPhno1());
			  pstmt.setString(8,htlBean.getPhno2());
			  pstmt.setString(9,htlBean.getRating());
			  pstmt.setString(10,htlBean.getEmail());
			  pstmt.setString(11,htlBean.getFax());
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
		  }catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	}
	

	public static int delHotel(int hotelid) {
		 Connection con = null;
		  PreparedStatement pstmt = null;
		  try
		  {
			  con=DB.getConnection(); 
			  
			  String del_str = 
					  "delete from book where hotel_id = ?";
				  
				  pstmt = (PreparedStatement) con.prepareStatement(del_str);
				  pstmt.setInt(1,hotelid);
				  int updateCount1 = pstmt.executeUpdate();
				  
				  con.close();
				  
				  return updateCount1; 
		  }catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	}

}