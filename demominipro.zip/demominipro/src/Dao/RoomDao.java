package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Beans.RoomBean;

public class RoomDao {

	public static int addRoom(RoomBean rmBean) {
		Connection con = null;
		  PreparedStatement pstmt = null;
		  try {
			  
			  con=DB.getConnection(); 
			  
			  String ins_str ="insert into demo values(?,?,?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,rmBean.getHotelid());
			  pstmt.setString(2,rmBean.getRoomid());
			  pstmt.setString(3,rmBean.getRoomno());
			  pstmt.setString(4, rmBean.getRoomtype());
			  pstmt.setInt(5, rmBean.getPrice());
			  pstmt.setBoolean(6,rmBean.isAval());
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
		  }catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	}

}
