##Please run the below DDL query before you execute this application.  

CREATE TABLE studentsrr
(studentid NUMBER(6),
name VARCHAR2(25));
