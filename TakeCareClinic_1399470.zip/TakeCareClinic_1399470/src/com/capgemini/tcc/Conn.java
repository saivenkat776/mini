package com.capgemini.tcc;

import java.sql.Connection;
import java.sql.DriverManager;

class Conn {		//CONNECTION CLASS

	public static Connection getCon() throws Exception //HANDLING THE EXCEPTION
	{
		
		Class.forName("oracle.jdbc.OracleDriver");
		Connection c=DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
		return c;
	}
	
}
