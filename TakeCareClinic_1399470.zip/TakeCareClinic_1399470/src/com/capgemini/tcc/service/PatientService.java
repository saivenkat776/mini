package com.capgemini.tcc.service;
import com.capgemini.tcc.bean.*;
interface IPatientService{
	int addPatientDetails(PatientBean patient);
	PatientBean getPatientDetails(int patientId);
}
public class PatientService implements IPatientService{

	public int addPatientDetails(PatientBean patient)
	{
		
		return 0;
	}
	public PatientBean getPatientDetails(int patientId)
	{
		PatientBean obj=new PatientBean();
		return obj;
	}
}
